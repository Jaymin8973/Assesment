// LoginPage.js
import React, { useContext } from 'react';
import { AppContext } from './AppContext';

const LoginPage = () => {
  const { isDarkMode, toggleTheme } = useContext(AppContext);

  return (
    <div className='wrap'>
    <div className={`container ${isDarkMode ? 'dark-theme' : ''}`}>
      <div>
  <div className={"login-box"}>
    <h1>Login</h1>
    <form>
      <input type="text" placeholder="Username" id="login-input" />
      <input type="password" placeholder="Password" id="login-input" />
      <button type="submit" id="login-button">Login</button>
    </form>
  </div>
  <div className="theme-toggle">
    <h2/>
    <label className="switch">
      <input type="checkbox" 
       value={isDarkMode ? 'Dark' : ''}
       onClick={toggleTheme}
      />
      <span className="slider"/>
    </label>
  </div>
</div>
</div>
</div>
          
  
  );
};

export default LoginPage;
