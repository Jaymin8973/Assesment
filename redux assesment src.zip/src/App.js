// App.js
// index.js or App.js

import './Style.css';
// index.js or App.js

import React from 'react';
import { AppProvider } from './AppContext';
import LoginPage from './Loginpage';


const App = () => {
  return (
    <AppProvider>
      <div className="App">
        <LoginPage/>
        {/* Other components/pages */}
      </div>
    </AppProvider>
  );
};

export default App;
